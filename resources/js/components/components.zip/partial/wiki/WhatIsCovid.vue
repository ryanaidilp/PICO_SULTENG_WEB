<template>
  <div class="p-6 mx-4 bg-white rounded-lg shadow-lg">
    <h3 class="text-lg font-bold text-left lg:text-3xl">
      Apa itu COVID-19?
      <i class="fas fa-viruses"></i>
    </h3>

    <p class="mt-4 text-sm text-justify md:text-lg">
      <i>2019 Novel Coronavirus (2019-nCoV)</i> adalah virus (
      <i>coronavirus</i>)
      yang diidentifikasi sebagai penyebab wabah penyakit pernapasan yang pertama kali terdeteksi di Wuhan, China.
      Awalnya, banyak pasien COVID-19 di Wuhan, Cina dilaporkan berhubungan dengan pasar makanan laut dan hewan di Wuhan. Hal ini mengindikasikan bahwa penyebaran terjadi dari hewan ke orang.
      Namun, semakin banyak pasien yang dilaporkan tidak memiliki riwayat paparan ke pasar hewan, menunjukkan bahwa penyebaran orang-ke-orang sedang terjadi.
      Nama
      <i>coronavirus</i> berasal dari bahasa Latin
      <span class="font-semibold">corona</span>, yang berarti "mahkota" atau "halo", mengacu pada penampilan virus yang menyerupai mahkota.
    </p>
  </div>
</template>