<template>
  <div>
    <div class="w-1/2 p-3">
      <!--119 Card-->
      <div class="p-6 bg-white rounded-lg shadow-lg hover:bg-blue-200">
        <a href="tel:119" class="flex flex-row items-center">
          <div class="flex-1 text-left">
            <h5 class="text-xl font-bold md:text-3xl">Call Center</h5>
            <h5 class="text-xs md:text-base">Nomor Darurat</h5>
            <div class="flex flex-row">
                <i class="hidden mt-1 text-xs text-blue-400 lg:block md:mt-3 md:text-lg fas fa-phone-alt" aria-hidden="true"/>
                <h3 class="ml-2 text-xs font-bold text-blue-400 md:text-2xl">119</h3>
            </div>
          </div>
        </a>
      </div>
      <!--119 Card-->
    </div>
    <div class="w-1/2 p-3">
      <!--119 Card-->
      <div class="p-6 bg-white rounded-lg shadow-lg hover:bg-blue-200">
        <a href="tel:0811404119" class="flex flex-row items-center">
          <div class="flex-1 text-left">
            <h5 class="text-xl font-bold md:text-3xl">Hotline</h5>
            <h5 class="text-xs md:text-base">Dinkes Sulteng
              </h5>
            <div class="flex flex-row">
                <i class="hidden mt-1 text-xs text-blue-400 lg:block md:mt-3 md:text-lg fas fa-phone-alt" aria-hidden="true"/>
            <h3 class="ml-2 text-xs font-bold text-blue-400 md:text-2xl">+62811-404-119</h3>
            </div>
          </div>
        </a>
      </div>
      <!--119 Card-->
    </div>
  </div>
</template>