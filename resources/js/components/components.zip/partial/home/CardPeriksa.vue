<template>
  <div class="w-auto mt-8">
    <div class="p-6 mx-4 text-white bg-blue-400 rounded-lg shadow-lg">
      <h3 class="text-xl font-bold lg:text-2xl">Ketahui Risiko dari COVID-19</h3>
      <div class="flex flex-col w-full lg:flex-row">
        <p class="w-full mt-4 text-xs text-justify lg:w-3/4 lg:text-lg">
          COVID-19 adalah penyakit yang disebabkan oleh
          <i>Novel Coronavirus 2019.</i>
          Gejala dari infeksi COVID-19 ini mirip dengan flu biasa. Meski begitu, COVID-19 masih memiliki fatalitas lebih tinggi.
          Penularan virus ini juga sangat cepat karena dapat berpindah dari orang ke orang. Bahkan kadang orang yang tertular tidak menunjukan gejala apapun.
          <br />
          <br />Apakah komiu bergejala? Ayo periksakan diri secara mandiri untuk mengetahui kondisi kamu.
        </p>
        <a
          href="https://corona.detexi.id"
          target="blank"
          class="w-full mx-auto my-2 text-xs font-bold text-center border-2 border-white rounded-md lg:my-auto lg:mx-2 lg:w-1/4 sm:p-2 lg:mx-16 lg:text-base hover:bg-blue-300"
        >Periksa Sekarang</a>
      </div>
    </div>
  </div>
</template>