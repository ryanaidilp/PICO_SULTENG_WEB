<template>
  <div class="w-full mt-4">
    <div class="p-6 mx-4 text-white bg-blue-400 rounded-lg shadow-lg">
      <h3 class="text-xl font-bold md:text-2xl">Donasi COVID-19</h3>
      <p class="mt-4 text-sm text-justify md:text-lg">
        Mari jo sama-sama bantu saudara-saudara kita yang terdapampak COVID-19 dan saudara-saudara kita yang
        saat ini berada di garda terdepan dalam melawan COVID-19 melalui donasi teman-teman semua. Bagaimana caranya kalau mau berdonasi? Gampang, tekan saja poster donasi nya maka teman-teman akan langsung diarahkan untuk menghubungi CP dari donasi yang teman-teman pilih.
      </p>
    </div>
  </div>
</template>