<template>
  <div class="p-6 mx-4 bg-white rounded-lg shadow-lg">
    <h3 class="text-lg font-bold text-left lg:text-3xl">
      Mythbuster
      <i class="fas fa-ban"></i>
    </h3>
    <p
      class="mt-4 text-sm md:text-lg"
    >Berikut ini adalah beberapa mitos yang beredar mengenai COVID-19, :</p>
    <p class="text-xs">*Catatan : Fakta ditandai dengan <i class="text-green-400 fas fa-check"></i> dan hoaks ditandai dengan <i class="text-red-400 fas fa-ban"></i></p>
    <ul class="mt-4 text-xs md:text-lg">
      <li>
        <i class="text-red-400 fas fa-ban"></i>
        COVID-19 tidak bisa hidup di area beriklim panas dan lembap.
      </li>
      <li>
        <i class="text-green-400 fas fa-check"></i>
        COVID-19 <b>bertahan hidup</b> di area beriklim panas dan lembap.
      </li>
      <li>
        <i class="mt-4 text-red-400 fas fa-ban"></i>
        Cuaca dingin dan salju bisa membunuh coronavirus.
      </li>
      <li>
        <i class="text-green-400 fas fa-check"></i>
        Cuaca dingin dan salju <b>tidak bisa</b> membunuh coronavirus.
      </li>
      
      <li>
        <i class="mt-4 text-red-400 fas fa-ban"></i>
        Mandi air panas bisa mencegah coronavirus.
      </li>
      <li>
        <i class="text-green-400 fas fa-check"></i>
        Mandi air panas <b>tidak bisa</b> mencegah coronavirus.
      </li>
      
      <li>
        <i class="mt-4 text-red-400 fas fa-ban"></i>
        <i>Hand dryers</i> bisa membunuh coronavirus.
      </li>
      <li>
        <i class="text-green-400 fas fa-check"></i>
        <i>Hand dryers</i> <b>tidak bisa</b> membunuh coronavirus.
      </li>

      <li>
        <i class="mt-4 text-red-400 fas fa-ban"></i>
        Sinar Ultraviolet bisa membunuh coronavirus.
      </li>
      <li>
        <i class="text-green-400 fas fa-check"></i>
        <b>Tidak</b>. Sinar UV dapat menyebabkan iritasi pada kulit.
      </li>

      <li>
        <i class="mt-4 text-red-400 fas fa-ban"></i>
        Menyemprotkan alkohol dan klorin ke seluruh tubuh bisa membunuh coronavirus.
      </li>
      <li>
        <i class="text-green-400 fas fa-check"></i>
        Virus yang sudah masuk ke dalam tubuh <b>tidak bisa dibunuh</b> dengan menyemprotkan alkohol/klorin ke seluruh tubuh.
      </li>

      <li>
        <i class="mt-4 text-red-400 fas fa-ban"></i>
        Vaksin untuk pneumonia bisa melindungi dari coronavirus.
      </li>
      <li>
        <i class="text-green-400 fas fa-check"></i>
        <b>Belum ada bukti</b> valid bahwa vaksin untuk pneumonia bisa digunakan untuk melindungi dari coronavirus.
      </li>
      
      <li>
        <i class="mt-4 text-red-400 fas fa-ban"></i>
        Pasien COVID-19 yang sudah meninggal bisa menularkan virus.
      </li>
      <li>
        <i class="text-green-400 fas fa-check"></i>
        Pasien COVID-19 yang sudah meninggal dan dimakamkan dengan protap COVID-19 <b>tidak bisa</b> menularkan virus.
      </li>
    </ul>
  </div>
</template>