<template>
  <div class="p-6 mx-4 bg-white rounded-lg shadow-lg">
    <h3 class="text-lg font-bold text-left lg:text-3xl">
      Bagaimana saya bisa tertular?
      <i class="fas fa-head-side-virus"></i>
    </h3>

    <ul class="mt-4 text-xs md:text-lg">
      <li>
        <i class="text-green-400 fas fa-check-circle"></i> Sumber penularan utama adalah tetesan kecil (
        <i>droplet</i>) dan kontak dekat
      </li>
      <li>
        <i class="text-green-400 fas fa-check-circle"></i> Saat bersin atau batuk, tetesan kecil ini akan keluar melalui hidung dan mulut
      </li>
      <li>
        <i class="text-green-400 fas fa-check-circle"></i>
        <i>Droplet</i> tersebut bisa membawa virus dan ketika masuk ke mata, hidung, atau mulut orang lain, maka mereka akan tertular
      </li>
      <li>
        <i class="text-green-400 fas fa-check-circle"></i> Penularan seperti ini dapat terjadi jika anda tidak menjaga jarak (+- 1 meter) dengan penderita
      </li>
      <li>
        <i class="text-green-400 fas fa-check-circle"></i> WHO telah menyatakan bahwa resiko tertular dari OTG dan feses sangat rendah
      </li>
    </ul>
  </div>
</template>