<template>
  <div class="p-6 mx-4 bg-white rounded-lg shadow-lg">
    <h3 class="text-lg font-bold text-left lg:text-3xl">
      Bagaimana jika saya terinfeksi?
      <i class="fas fa-allergies"></i>
    </h3>
    <p
      class="mt-4 md:text-lg"
    >Pemerintah telah menginstruksikan isolasi mandiri bagi siapapun yang dalam 14 hari terakhir melakukan perjalanan ke wilayah transmisi COVID-19 atau pun yang pernah melakukan kontak langsung dengan pasien COVID-19. Selain itu, beberapa hal yang bisa dilakukan jika merasa anda terinfeksi adalah :</p>
    <ul class="mt-4 text-xs md:text-base">
      <li>
        <i class="text-green-400 fas fa-check"></i>
        Isolasi mandiri di rumah.
      </li>
      <li>
        <i class="text-green-400 fas fa-check"></i>
        Isolasi mandiri tidak disarankan bagi yang memiliki riwayat penyakit lainnya seperti diabetes, penyakit jantung, kanker, paru kronis, AIDS, dsb.
      </li>
      <li>
        <i class="text-green-400 fas fa-check"></i>
        Gunakan kamar terpisah jika tinggal bersama anggota keluarga lainnya. Upayakan menjaga jarak 1 meter dari anggota keluarga.
      </li>
      <li>
        <i class="text-green-400 fas fa-check"></i>
        Gunakan masker selama masa isolasi diri.
      </li>
      <li>
        <i class="text-green-400 fas fa-check"></i>
        Jangan pergi bekerja, sekolah, atau ke tampat keramaian.
      </li>
      <li>
        <i class="text-green-400 fas fa-check"></i>
        Rutin melakukan pengukuran suhu badan harian dan observasi gejala klinis.
      </li>
      <li>
        <i class="text-green-400 fas fa-check"></i>
        Hindari pemakaian bersama peralatan makan, mandi, dan seprai.
      </li>
      <li>
        <i class="text-green-400 fas fa-check"></i>
        Hindari menggunakan transportasi umum.
      </li>
      <li>
        <i class="text-green-400 fas fa-check"></i>
        Menerapkan Perilaku Hidup Bersih dan Sehat atau PHBS dengan mengonsumsi makan bergizi, rutin mencuci tangan, serta melakukan etika batuk dan bersin yang benar.
      </li>
      <li>
        <i class="text-green-400 fas fa-check"></i>
        Perbanyak istrahat di rumah.
      </li>
      <li>
        <i class="text-green-400 fas fa-check"></i>
        Berada di ruang terbuka dan berjemur di bawah sinar matahari setiap pagi.
      </li>
      <li>
        <i class="text-green-400 fas fa-check"></i>
        Jaga kebersihan rumah dengan cairan disinfektan.
      </li>
      <li>
        <i class="text-green-400 fas fa-check"></i>
        Segera menghubungi fasilitas kesehatan jika kondisi kesehatan memburuk untuk penanganan lanjutan.
      </li>
    </ul>
  </div>
</template>